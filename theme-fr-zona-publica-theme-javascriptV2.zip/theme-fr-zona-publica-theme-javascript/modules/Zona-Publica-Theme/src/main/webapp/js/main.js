	/*AUI().ready(


	This function gets loaded when all the HTML, not including the portlets, is
	loaded.
	

	function() {
	}
);*/
/*
Liferay.Portlet.ready(

	
	This function gets loaded after each and every portlet on the page.

	portletId: the current portlet's id
	node: the Alloy Node object of the current portlet
	

	function(portletId, node) {
	}
);*/
/*
Liferay.on(
	'allPortletsReady',

	
	This function gets loaded when everything, including the portlets, is on
	the page.
	

	function() {
	}
);
*/
var defaultFontSize=16; 
var currentFontSize; 

function setFontSize(newFontSize){jQuery('html').css('font-size',newFontSize+'px');}

function saveSettings(){	
	var cookieData = currentFontSize;	
	var classBody = '';
	if($("body").hasClass("agplus")){
		classBody = 'agplus';
	}else if($("body").hasClass("agmenus")){
		classBody = 'agplus';
	}
	localStorage.setItem('resize', cookieData);
	localStorage.setItem('resizeclass', classBody);
	
	var classBodyScale = '';
	var classBodyHigh = '';
	var classSenas = '';					
	
	if($("html").hasClass("scalegrayGeneral")){
		classBodyScale = 'scalegrayGeneral'
	}
	if($("html").hasClass("altoContrasGeneral")){
		classBodyHigh = 'altoContrasGeneral'
	}
	if($("html").hasClass("senasGeneral")){
		classSenas = 'senasGeneral'
	}								   						 
	localStorage.setItem('scalegrayGeneral', classBodyScale);
	localStorage.setItem('altoContrasGeneral', classBodyHigh);
	localStorage.setItem('senasGeneral', classSenas);												 
}

(function($) {
    $.fn.fontResize = function(options) {
        var increaseCount = 0;		
        var self = this;

        var changeFont = function(element, amount) {
            var baseFontSize = parseInt($('html').css("font-size"));		
            element.css('font-size', (baseFontSize + amount) + 'px');
			currentFontSize = (baseFontSize + amount);
        };

        options.increaseBtn.on('click', function(e) {
            e.preventDefault();
			$('body').addClass('agplus');
			$('body').removeClass('agmenus');
            /*if (increaseCount === 2) {
                return;
            }
            self.each(function(index, element) {
                changeFont($(element), 2);
            });
            increaseCount++;*/
			currentFontSize = currentFontSize + 2;
			if(currentFontSize > 20){currentFontSize = 20;} 
			setFontSize(currentFontSize);
        });

        options.decreaseBtn.on('click', function(e) {
            e.preventDefault();
			$('body').addClass('agmenus');
			$('body').removeClass('agplus');
            /*if (increaseCount === 0) {
				$('body').removeClass('agmenus');
                return;
            }
            self.each(function(index, element) {
                changeFont($(element), -2);
            });
            increaseCount--;*/
			currentFontSize = currentFontSize - 2;
			if(currentFontSize < 16){currentFontSize = 16;}
			setFontSize(currentFontSize);
        });
		if(currentFontSize = 16){
			$('body').removeClass('agmenus');
		}
		
    }
})(jQuery);


(function($) {
	$.fn.clickFucti = function(options) {
		options.grayBtn.on('click', function(e) {
			e.preventDefault();
			if($("html").hasClass("scalegrayGeneral")){
				$('html').removeClass('scalegrayGeneral');
				$('.usertoolsCont').removeClass('active');
				$( ".modal-backdrop" ).remove();
			}else{
				$('html').addClass('scalegrayGeneral');
				$('html').removeClass('altoContrasGeneral');
				$('.usertoolsCont').removeClass('active');
				$( ".modal-backdrop" ).remove();
			}
		});
		
		options.highBtn.on('click', function(e) {
			e.preventDefault();
			if($("html").hasClass("altoContrasGeneral")){
				$('html').removeClass('altoContrasGeneral');
				$('.usertoolsCont').removeClass('active');
				$( ".modal-backdrop" ).remove();
			}else{
				$('html').addClass('altoContrasGeneral');
				$('html').removeClass('scalegrayGeneral');
				$('.usertoolsCont').removeClass('active');
				$( ".modal-backdrop" ).remove();
			}
		});
		options.senasBtn.on('click', function(e) {
            e.preventDefault();
            if($("html").hasClass("senasGeneral")){
                $('html').removeClass('senasGeneral');
				$('.usertoolsCont').removeClass('active');
				$( ".modal-backdrop" ).remove();
            }else{
                $('html').addClass('senasGeneral');
				$('.usertoolsCont').removeClass('active');
				$( ".modal-backdrop" ).remove();
            }
        });									  		   
	}
})(jQuery);

//Validar disponibilidad del LocalStorage
function storageDisponible(type) {
    try {
        var storage = window[type],
            x = '__storage_test__';
        storage.setItem(x, x);
        storage.removeItem(x);
        return true;
    } catch (e) {
        return e instanceof DOMException && (
                // todo excepto Firefox
                e.code === 22 ||
                // Firefox
                e.code === 1014 ||
                // prueba campo nombre también, el código puede no estar presente
                // todo excepto Firefox
                e.name === 'QuotaExceededError' ||
                // Firefox
                e.name === 'NS_ERROR_DOM_QUOTA_REACHED') &&
            // reconocer QuotaExceededError solo si ya hay algo almacenado
            storage.length !== 0;
    }
}

$(function() {

    // zoom tools
    $(".usertools__btn").click(function(e) {
        e.preventDefault();
        $(".usertools").toggleClass("active");
    });

    $('html').fontResize({
        increaseBtn: $('.agrandar-letra'),
        decreaseBtn: $('.achicar-letra')
    });
	$('html').clickFucti({
        grayBtn: $('.scalegray-btn'),
        highBtn: $('.contr-btn'),
        senasBtn: $('.senas-btn')								 
    });
    
	$(".btnToolEnlace").click(function(e) {
        e.preventDefault();
		if ($("body").is('.activeacc')) {
		    $('body').removeClass('activeacc');
			$( ".modal-backdrop" ).remove();
			$( ".usertoolsCont" ).css("z-index","1041");
			$('.usertoolsCont').removeAttr('aria-modal');	
			$('.usertools__link').attr('tabindex','-1');
		}
		else{			
		    $('body').addClass('activeacc');
			var txt1 = "<div class='modal-backdrop show'></div>";          		
			$(".activeacc").after(txt1);
			$( ".usertoolsCont" ).css("z-index","9999");
			$('.usertoolsCont').attr('aria-modal','true');			
			$('.usertools__link').attr('tabindex','0');
			$('.activeacc .btnToolEnlace').focus();
		}
		if ($(".usertoolsCont").is('.active')) {
			$('.usertoolsCont').removeClass('active');
		}else{
			$(".usertoolsCont").addClass("active");
		}
	});
	$(".btnToolEnlaceinto").click(function(e) {
		e.preventDefault();
		if ($("body").is('.activeacc')) {
		    $('body').removeClass('activeacc');
			$( ".modal-backdrop" ).remove();
			$( ".usertoolsCont" ).css("z-index","1041");
			$('.usertoolsCont').removeAttr('aria-modal');	
			$('.usertools__link').attr('tabindex','-1');
		}
		else{			
		    $('body').addClass('activeacc');
			var txt1 = "<div class='modal-backdrop show'></div>";          		
			$(".activeacc").after(txt1);
			$( ".usertoolsCont" ).css("z-index","9999");
			$('.usertoolsCont').attr('aria-modal','true');			
			$('.usertools__link').attr('tabindex','0');
			$('.activeacc .btnToolEnlace').focus();
		}
		if ($(".usertoolsCont").is('.active')) {
			$('.usertoolsCont').removeClass('active');
		}else{
			$(".usertoolsCont").addClass("active");
		}
	});
	
	
	
	// cerrar cookies

	$('.btn--close-alert, .zp-alerta-box--cookies--btn').click(function () {
		$(this).parent().fadeOut();
		if (storageDisponible('localStorage')) {
        try{
            localStorage.setItem("cookies", true);
        }catch(e){
            console.error(e);
        }
        }
	});

	$('.close-alert-info, .close-alert').click(function () {
		$(this).parents('.zp-alerta-box').slideUp();
	});
    
    $(document).ready(function() {
    	try{
    	if(typeof(Storage) !== "undefined") {
    		 var cookies = localStorage.getItem("cookies");
    		 if(cookies){
    			 $('.zp-alerta-box--cookies').fadeOut();
    		 }else{
    			 $('.zp-alerta-box--cookies').fadeIn(); 
    		 }
    	 }else{
    		 $('.zp-alerta-box--cookies').fadeIn();
    	 }
    	 }catch(e){
    		 $('.zp-alerta-box--cookies').fadeIn();
    	 }	 
		
    })

	// menu footer
	
	$('.footer--publico .dropdown-toggle').click(function () {
	   
	    $(this).parent().siblings().children().next().fadeOut().removeClass('active');
	    $(this).parent().siblings().removeClass('opened');
	    $(this).next('ul').slideToggle();
	    $(this).parent().toggleClass('opened');
	    $("html, body").animate({ scrollTop: $(document).height() }, 800);
	    return false;
	});
    
    moveScroller();

    function moveScroller() {
        var $anchor = $("#scroller-anchor");
        var $scroller = $('.zp-header-publico, .zp-content');

        var move = function() {
            var st = $(window).scrollTop();
            var ot = $anchor.offset().top;
               if ($('body').width()<768){
                      if(st > ot) {
                    $scroller.addClass('menuIsSticky')
                } else {
                    $scroller.removeClass('menuIsSticky')
                }
               }
               else{
                $scroller.removeClass('menuIsSticky') 
            }
        };
        $(window).scroll(move);
        move();
    }
    
    $(document).ready(function(){
       moveScroller();
    })
    $(document).on('change mouseover','body',function(){
       moveScroller();
    })


    // submenu	
     $( ".dropdown-toggle" ).click(function() {
            
           
            $(this).next(".journal-content-article").slideToggle();
            $(this).parent().toggleClass('activeItem');
            $(this).parent().siblings().children().next().slideUp();
            $(this).parent().siblings().removeClass('activeItem');
           
            return false

        });
	
     $( ".dropdown-toggle-submenu" ).click(function() {
            
            $('.dropdown-toggle-submenu').removeClass('activeItem');
            $( this ).next(".zp-dropdown-submenu").slideToggle();
            $( this ).toggleClass('activeItem');
            $(this).parent().siblings().children().next().slideUp();
            $(this).parent().siblings().children().removeClass('activeItem');
           
            return false

        });
     
     $(document).click(function(e) {
    	    var container = $(".zp-dropdown .journal-content-article");
    	    if (!container.is(e.target) && container.has(e.target).length === 0) {
    	        $(".dropdown-toggle").parent().siblings().children().next().slideUp('fast');
    	        $(".dropdown-toggle").parent().siblings().removeClass('activeItem');
    	    }
    	});
     
     
    // tooltip
    $('[data-toggle="tooltip"]').tooltip(); 
    
    // Componente Ancla
    $(".zp-anclas-list__item a").on('click', function(e) {
        e.preventDefault();
        var target = $(this).attr('href');
        $('html, body').animate({
          scrollTop: ($(target).offset().top - 80)
        }, 1500);
     });


    // funcion para mostrar/ocultar acordeon
    $('[data-toggle="collapse"]').click(function(e){
    	  e.preventDefault();
    	  $(this).toggleClass('opened');
});

// alerta seguir leyendo


$(window).scroll(function() {
    if ($(window).scrollTop() >= 400 && $(window).scrollTop() <= ($(document).height() - 400)) {
        $('.zp-alerta-leyendo').fadeOut();
    }
    else {
        $('.zp-alerta-leyendo').fadeIn();
    }
});

})

// Funcion para cargar el modal de Opinat
function loadOpinatModal(surveyUrl){
	document.getElementById('opinatIframe').setAttribute('src', surveyUrl);
	document.getElementById('modalEncuesta').style.display = "block";
	document.getElementById('modalEncuesta').style.opacity = 1;
}

//Prueba
const KEYCODE_TAB = 9;
const KEYCODE_ESCAPE = 27;
const KEYCODE_ENTER = 13;
// Function to trap focus inside the modal dialog
// Credit to Hidde de Vries for providing the original code on his website:

trapFocusInModal = function (el) {

    // Gather all focusable elements in a list
    var query = "a[href]:not([disabled]), button:not([disabled]), textarea:not([disabled]), input[type='email']:not([disabled]), input[type='text']:not([disabled]), input[type='radio']:not([disabled]), input[type='checkbox']:not([disabled]), select:not([disabled]), [tabindex='0']"
    var focusableEls = el.querySelectorAll(query);
    var firstFocusableEl = focusableEls[0];
    var lastFocusableEl = focusableEls[focusableEls.length - 1];

    // Add the key listener to the modal container to listen for Tab, Enter and Escape
    el.addEventListener('keydown', function(e) {
        var isTabPressed = (e.key === "Tab" || e.keyCode === KEYCODE_TAB);
        var isEscPressed = (e.key === "Escape" || e.keyCode === KEYCODE_ESCAPE);
  
        // Define behaviour for Tab or Shift+Tab
        if (isTabPressed) {
            // Shift+Tab
            if (e.shiftKey) {
                if (document.activeElement === firstFocusableEl) {
                    lastFocusableEl.focus();
                    e.preventDefault();
                }
            }
            
            // Tab
            else {
                if (document.activeElement === lastFocusableEl) {
                    firstFocusableEl.focus();
                    e.preventDefault();
                }
            }
        }
        
        // Define behaviour for Escape
        if (isEscPressed) {
            el.querySelector("button.close").click();
        }
    });
};


var domIsReady = (function(domIsReady) {

    var isBrowserIeOrNot = function() {
        return (!document.attachEvent || typeof document.attachEvent === "undefined" ? 'not-ie' : 'ie');
    }

    domIsReady = function(callback) {
        if(callback && typeof callback === 'function'){
            if(isBrowserIeOrNot() !== 'ie') {
                document.addEventListener("DOMContentLoaded", function() {
                    return callback();
                });
            } else {
                document.attachEvent("onreadystatechange", function() {
                    if(document.readyState === "complete") {
                        return callback();
                    }
                });
            }
        } else {
            console.error('The callback is not a function!');
        }
    }

    return domIsReady;
})(domIsReady || {});


(function(document, window, domIsReady, undefined) {

    // Check if DOM is ready
    domIsReady(function() {

        // Trap tab order within modal
        if (document.getElementById("usertoolsCont1")) {			
            var modal = document.getElementById("usertoolsCont1");
            trapFocusInModal(modal);
        }
		if (document.getElementById("modalPerfilador")) {			
            var modalPer = document.getElementById("modalPerfilador");
            trapFocusInModal(modalPer);
        }
        
   });
})(document, window, domIsReady);

//LocalStorage resize
function revertFontSize(){
	currentFontSize = defaultFontSize;
	setFontSize(defaultFontSize);
}

function setUserSettings(fontSize_user){	
	currentFontSize=defaultFontSize;
	if(parseInt(fontSize_user)){currentFontSize=parseInt(fontSize_user);}
	setFontSize(currentFontSize);	
}



function readLocal(cookie_name) {
	var cat = localStorage.getItem(cookie_name)?? false;
	return cat;
}

function setUserOptions(){
	var userDataRaw = readLocal("resize");	
	var reClassData = readLocal("resizeclass");	
	if(userDataRaw != "16"){
		jQuery('body').addClass(reClassData);
	}	
	
	if(!userDataRaw){
		revertFontSize();
	}	
	else{
		var userData = userDataRaw;
		setUserSettings(userData);
	}
	
	var scaleClassData = readLocal("scalegrayGeneral");	
	var highClassData = readLocal("altoContrasGeneral");	
	var senasClassData = readLocal("senasGeneral");													
	jQuery('html').addClass(scaleClassData);
	jQuery('html').addClass(highClassData);
	jQuery('html').addClass(senasClassData);										
}

function documentReady(){
	setUserOptions();
}

jQuery(document).ready(function(){ documentReady(); });
$(window).on('beforeunload', function(){
	saveSettings();
});