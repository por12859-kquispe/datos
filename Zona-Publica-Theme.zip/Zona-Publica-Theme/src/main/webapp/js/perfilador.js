var generacion = "generacion";
var construyendo = "construyendo";
var consolidando = "consolidando";
var disfrutando = "disfrutando";

var mujer = "mujer";
var hombre = "hombre";
var empresas = "empresas";
var pensionado = "pensionado";
var sinPerfil = "sinPerfil";
var otroMomento = "otroMomento";

var actorActualStorage = undefined;
var edadActualStorage = undefined;
var actorActual = undefined;
var edadActual = undefined;
var segmentoStorage = undefined;
var segmentoActual = undefined;

if (tienePreferencias()) {
    validarRedireccionPreferencias();
}

var locationPathName = "/web/personas/inicio"

// inicio validar si existe perfil al hacer scroll
if (storageDisponible('localStorage')) {
var altura = 0;
var aux = 0;
var resultado = 0;
var scroll_position = 0;
var scroll = false;

if(locationPathName == homePage || homePage=="/" || homePage=="/web/personas/") {
	if(!tienePreferencias()){
		jQuery('.perfilador').fadeIn();
		jQuery('.perfilador').focus();
		jQuery('body').css('overflow', 'hidden');
	}
} else {
	window.addEventListener('scroll', function(e) {
		scroll_position = document.documentElement.scrollTop;
		if (/constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification)) {
			scroll_position = document.body.scrollTop;
		}
	    
	   altura = document.body.scrollHeight;
	   aux = $(window).height();
	   resultado = (altura - aux);
	        if (!scroll) {
	            if(scroll_position >= resultado){
	                if( !tienePreferencias() ) {
						if( !isOtroMomento() ) {
                            if(validacionSYQ()){
                                jQuery('.perfilador').fadeIn();
								jQuery('.perfilador').focus();
                                jQuery('body').css('overflow', 'hidden');                                
                           }
						}
	                }
	            }    
	        }
	    });
}
}

// inicio validar si existe perfil al hacer scroll

jQuery(document).ready(function() {
	
    jQuery('.zp-perfiladorBar').hide();
    jQuery('.menuPorvenir').hide();

    //abrir y cerrar el perfilador
    jQuery('.showPerfilador').click(function() {
        jQuery('.perfilador').fadeIn();
		jQuery('.perfilador').focus();
		jQuery('body').css('overflow', 'hidden');
    });

    if (tienePreferencias()) {
        cargaPreferencias();
    } else {
        console.log("no hay perfilacion guardada");
        if (esHome()) {
            if (storageDisponible('localStorage')) {
            jQuery('.perfilador').fadeIn();
			jQuery('.perfilador').focus();
			jQuery('body').css('overflow', 'hidden');
        }
        }
         if (storageDisponible('localStorage')) {
                        
            jQuery('.zp-perfiladorBar.sin-perfilar').show();       
            jQuery('.menuPorvenir.sin-perfilar').show();
            
    }
    }

    jQuery('.section-mujer .url-porvenir').removeAttr('href');
    jQuery('.section-hombre .url-porvenir').removeAttr('href');

    // agragando actor mujer a storage
    jQuery("#boton-mujer").click(function() {
        jQuery('.section-options, .salir-perfilador').hide();
        jQuery('.section-mujer').fadeIn();
        actorActual = mujer;
    });

    // agragando actor hombre a storage
    jQuery("#boton-hombre").click(function() {
        jQuery('.section-options, .salir-perfilador').hide();
        jQuery('.section-hombre').fadeIn();
        actorActual = hombre;
    });

    // agragando pensionado a storage
    jQuery(".pensionado-btn .btn--next").click(function() {
        actorActual = pensionado;
        try {
            var perfilador = JSON.parse(localStorage.getItem("perfilador"));
            perfilador = setPerfiladorActor(perfilador, pensionado);
            perfilador = setPerfiladorPreferencias(perfilador, pensionado, null, null);
            localStorage.setItem("perfilador", JSON.stringify(perfilador));
        } catch (e) {
            console.error(e);
        }
        window.location.href = getUrlSitio(pensionado);
    });

    // agragando data de mujer y hombre a storage
    jQuery('.url-porvenir').click(function() {
        if (actorActual == mujer ){
            edadActual = jQuery(".section-mujer .valueSlider").asRange('get');
            segmentoActual = getSegmento( actorActual, edadActual);
        }else if(actorActual == hombre ){
            edadActual = jQuery(".section-hombre .valueSlider").asRange('get');
            segmentoActual = getSegmento( actorActual, edadActual);
        }
        validarCambiosPerfil();
    });

    // no en este momento
    jQuery(".salir-perfilador .btn").removeAttr( "href" );
    jQuery(".salir-perfilador .btn").click(function() {
        actorActual = sinPerfil;
        try {
            var perfilador = JSON.parse(localStorage.getItem("perfilador"));
            perfilador = setPerfiladorActor(perfilador, actorActual);
            perfilador = setPerfiladorPreferencias(perfilador, sinPerfil, null, otroMomento);
            sessionStorage.setItem("perfilador", JSON.stringify(perfilador));
        } catch (e) {
            console.error(e);
        }
        jQuery('.perfilador').fadeOut();
		jQuery('body').css('overflow', 'visible');
    })

    // agragando actor empresas a storage
    jQuery("#boton-empresa").removeAttr( "href" );
    jQuery("#boton-empresa").click(function() {
        actorActual = empresas;
        try {
            var perfilador = JSON.parse(localStorage.getItem("perfilador"));
            perfilador = setPerfiladorActor(perfilador, empresas);
            perfilador = setPerfiladorPreferencias(perfilador, empresas, null, null);
            localStorage.setItem("perfilador", JSON.stringify(perfilador));
        } catch (e) {
            console.error(e);
        }
        window.location.href = getUrlSitio(empresas);
    });

});

function validarCambiosPerfil(){
    if (actorActual != undefined) {
        if (actorActual == mujer ) {
            segmentoStorage = getSegmento( actorActualStorage, edadActualStorage);
            segmentoActual = getSegmento( actorActual, edadActual);
            if( segmentoStorage !== undefined ){
                if( segmentoActual !== undefined  && segmentoActual != segmentoStorage ){
                    setPreferenciasPersonas();
                    setPerfiladorBarColor( getSegmento(actorActual, edadActual ) );
                    resetPantallaSeleccionPerfilador();
                    jQuery('.perfilador').fadeOut();
					jQuery('body').css('overflow', 'visible');
                }else if( segmentoActual == segmentoStorage ){
                    setPreferenciasPersonas();
                    setPerfiladorBarColor( getSegmento(actorActual, edadActual ) );
                    resetPantallaSeleccionPerfilador();
                    jQuery('.perfilador').fadeOut();
					jQuery('body').css('overflow', 'visible');
                }
            }else if( segmentoStorage == undefined ){
                setPreferenciasPersonas();
                setPerfiladorBarColor( getSegmento(actorActual, edadActual ) );
                validarRedireccionPreferencias();
                resetPantallaSeleccionPerfilador();
                jQuery('.perfilador').fadeOut();
				jQuery('body').css('overflow', 'visible');
            }
        }else if ( actorActual == hombre) {
            segmentoStorage = getSegmento( actorActualStorage, edadActualStorage);
            segmentoActual = getSegmento( actorActual, edadActual);
            if( segmentoStorage !== undefined ){
                if( segmentoActual !== undefined  && segmentoActual != segmentoStorage ){
                    setPreferenciasPersonas();
                    setPerfiladorBarColor( getSegmento(actorActual, edadActual ) );
                    resetPantallaSeleccionPerfilador();
                    jQuery('.perfilador').fadeOut();
					jQuery('body').css('overflow', 'visible');
                }else if( segmentoActual == segmentoStorage ){
                    setPreferenciasPersonas();
                    setPerfiladorBarColor( getSegmento(actorActual, edadActual ) );
                    resetPantallaSeleccionPerfilador();
                    jQuery('.perfilador').fadeOut();
					jQuery('body').css('overflow', 'visible');
                }
            }else if( segmentoStorage == undefined ){
                setPreferenciasPersonas();
                setPerfiladorBarColor( getSegmento(actorActual, edadActual ) );
                validarRedireccionPreferencias();
                resetPantallaSeleccionPerfilador();
                jQuery('.perfilador').fadeOut();
				jQuery('body').css('overflow', 'visible');
            } 
        }
    }// fin actorActual
}

function setPreferenciasPersonas(){
    try {
        var perfilador = JSON.parse(localStorage.getItem("perfilador"));
        perfilador = setPerfiladorActor(perfilador, actorActual);
        if( perfilador.otroMomento !== null &&  perfilador.otroMomento !== undefined ){
            perfilador = setPerfiladorPreferencias(perfilador, actorActual, edadActual, perfilador.otroMomento);
        }else{
            perfilador = setPerfiladorPreferencias(perfilador, actorActual, edadActual, null);
			window.location.href = getUrlSitio(getSegmento(perfilador.actor, perfilador.edad));
        }
        
        localStorage.setItem("perfilador", JSON.stringify(perfilador));
    } catch (e) {
        console.error(e);
    }
}//Fin setPreferenciasPersonas()

jQuery("#edadMujer").asRange({
    step: 1,
    range: false,
    min: 0,
    max: 10,
    onChange: function(value) {
        var value = jQuery(".section-mujer .valueSlider").asRange('get');
        if (value >= "29") {
            jQuery('.section-mujer .form-box-edad').addClass('yellow');
            jQuery('.section-mujer .form-box-edad').removeClass('orange dark');
            jQuery('.section-mujer .edad p').html('Construyendo tu Porvenir');
            jQuery('.section-mujer .generacion-description').html('Tienes entre 29 y 46 años');
            jQuery('.section-mujer .ahorro-result').html('Estás fortaleciendo tu ahorro');
        } else {
            jQuery('.section-mujer .form-box-edad').removeClass('yellow');
            jQuery('.section-mujer .edad p').html('Generación Porvenir');
            jQuery('.section-mujer .generacion-description').html('Tienes entre 18 y 28 años');
            jQuery('.section-mujer .ahorro-result').html('Estás iniciando tu ahorro');
        }
        if (value >= "47") {
            jQuery('.section-mujer .form-box-edad').addClass('orange');
            jQuery('.section-mujer .form-box-edad').removeClass('yellow dark');
            jQuery('.section-mujer .edad p').html('Consolidando tu porvenir');
            jQuery('.section-mujer .generacion-description').html('Tienes entre 47 y 56 años');
            jQuery('.section-mujer .ahorro-result').html('Estás asegurando tu ahorro');
        } else {
            jQuery('.section-mujer .form-box-edad').removeClass('orange');

        }
        if (value >= "57") {
            jQuery('.section-mujer .form-box-edad').addClass('dark');
            jQuery('.section-mujer .form-box-edad').removeClass('yellow orange');
            jQuery('.section-mujer .edad p').html('Disfrutando tu Porvenir');
            jQuery('.section-mujer .generacion-description').html('Tienes más de 57 años');
            jQuery('.section-mujer .ahorro-result').html('Estás beneficiándote de tu ahorro');
        } else {
            jQuery('.section-mujer .form-box-edad').removeClass('dark');
        }

        if (value == "57") {
            if (jQuery(window).width() < 768) {
                 jQuery('.section-mujer .selector-range .edad-3').addClass('dark');
            } else {
                 jQuery('.section-mujer .selector-range .edad-3').removeClass('dark');
            }
        } else {
             jQuery('.section-mujer .selector-range .edad-3').removeClass('dark');

        }

    },

});

jQuery("#edadHombre").asRange({
    step: 1,
    range: false,
    min: 0,
    max: 10,
    onChange: function(value) {
        var value = jQuery(".section-hombre .valueSlider").asRange('get');
        if (value >= "29") {
            jQuery('.section-hombre .form-box-edad').addClass('yellow');
            jQuery('.section-hombre .form-box-edad').removeClass('orange dark');
            jQuery('.section-hombre .edad p').html('Construyendo tu Porvenir');
            jQuery('.section-hombre .generacion-description').html('Tienes entre 29 y 51 años');
            jQuery('.section-hombre .ahorro-result').html('Estás fortaleciendo tu ahorro');
        } else {
            jQuery('.section-hombre .form-box-edad').removeClass('yellow');
            jQuery('.section-hombre .edad p').html('Generación Porvenir');
            jQuery('.section-hombre .generacion-description').html('Tienes entre 18 y 28 años');
            jQuery('.section-hombre .ahorro-result').html('Estás iniciando tu ahorro')
        }
        if (value >= "52") {
            jQuery('.section-hombre .form-box-edad').addClass('orange');
            jQuery('.section-hombre .form-box-edad').removeClass('yellow dark');
            jQuery('.section-hombre .edad p').html('Consolidando Porvenir');
            jQuery('.section-hombre .generacion-description').html('Tienes entre 52 y 61 años');
            jQuery('.section-hombre .ahorro-result').html('Estás asegurando tu ahorro');
        } else {
            jQuery('.section-hombre .form-box-edad').removeClass('orange');

        }
        if (value >= "62") {
            jQuery('.section-hombre .form-box-edad').addClass('dark');
            jQuery('.section-hombre .form-box-edad').removeClass('yellow orange');
            jQuery('.section-hombre .edad p').html('Disfrutando tu Porvenir');
            jQuery('.section-hombre .generacion-description').html('Tienes más de 62 años');
            jQuery('.section-hombre .ahorro-result').html('Estás beneficiándote de tu ahorro');
        } else {
            jQuery('.section-hombre .form-box-edad').removeClass('dark');

        }

        if (value == "62") {
            if (jQuery(window).width() < 768) {
             jQuery('.section-hombre .selector-range .edad-3').addClass('dark');
         }
         else {
            jQuery('.section-hombre .selector-range .edad-3').removeClass('dark');
        }
        }
        else {
            jQuery('.section-hombre .selector-range .edad-3').removeClass('dark');
        }

    }
});

function tienePreferencias() {
    if (storageDisponible('localStorage')) {

        var perfilador = localStorage.getItem("perfilador");
        if (perfilador === undefined || perfilador === null) {
            return false;
        } else if ( JSON.parse(perfilador).hasOwnProperty("actor") ) {
            return true;
        } else {
            return false;
        }
    }
    return false;
} //fin tienePreferencias()

function setPerfiladorActor(perfilador, actor) {
    if (perfilador === undefined || perfilador === null) {
        perfilador = {};
    }
    perfilador.actor = actor;
    return perfilador;
} //fin consultaPerfilador()

function setPerfiladorPreferencias(perfilador, actor, edad, otroMom) {
    if (perfilador === undefined || perfilador === null) {
        perfilador = {};
    }
    perfilador.actor = actor;
    perfilador.edad = edad;
    perfilador.otroMomento = otroMom;
    perfilador = limpiarPropiedades( perfilador, actor );
    return perfilador;
} //fin setPerfiladorPreferencias()

function limpiarPropiedades( perfilador, actor ){
    if( actor == pensionado || actor == empresas ){
        delete perfilador.edad ;
        delete perfilador.otroMom ;
    }else if( actor == sinPerfil ){
        delete perfilador.edad ;
    }
    return perfilador;
}

function cargaPreferencias() {
    var perfilador = JSON.parse(localStorage.getItem("perfilador"));
    actorActualStorage = perfilador.actor;
    
    if (perfilador.actor == mujer) {
        if (perfilador.hasOwnProperty("edad")) {
            edadActualStorage = perfilador.edad;
            jQuery(".section-mujer .valueSlider").asRange('val', perfilador.edad);
        }		
        jQuery('.section-mujer .url-porvenir').attr('href', getUrlSitio(   getSegmento(perfilador.actor, edadActualStorage )  ) );
		//window.location.href = getUrlSitio(   getSegmento(perfilador.actor, edadActualStorage )  );
    } else if (perfilador.actor == hombre) {
        if (perfilador.hasOwnProperty("edad")) {
            edadActualStorage = perfilador.edad;
            jQuery(".section-hombre .valueSlider").asRange('val', perfilador.edad);
        }		
        jQuery('.section-hombre .url-porvenir').attr('href', getUrlSitio( getSegmento(perfilador.actor, edadActualStorage )));
		//window.location.href = getUrlSitio( getSegmento(perfilador.actor, edadActualStorage ));
    }
    setPerfiladorBarColor( getSegmento( perfilador.actor, edadActualStorage ) );
    validarRedireccionPreferencias();
} // fin cargaPreferencias()
function validarRedireccionPreferencias() {
    if (esHome()) {
        var perfiladorSession = undefined ;
        var perfiladorSessionJs = undefined ;
        var otroMomentoSession = undefined ;
        if (storageDisponible('sessionStorage')) {
            perfiladorSession = sessionStorage.getItem("perfilador");
            if (perfiladorSession !== null && perfiladorSession !== undefined) {
                perfiladorSessionJs =  JSON.parse( perfiladorSession );
                otroMomentoSession = perfiladorSessionJs.otroMomento;
            }
        }
        var perfilador = JSON.parse(  localStorage.getItem("perfilador"));
        if (otroMomentoSession !== null && otroMomentoSession !== undefined) {
            if (getSegmento(perfilador.actor, perfilador.edad) == generacion ||
                getSegmento(perfilador.actor, perfilador.edad) == construyendo ||
                getSegmento(perfilador.actor, perfilador.edad) == consolidando ||
                getSegmento(perfilador.actor, perfilador.edad) == disfrutando) {
                window.location.href = getUrlSitio(getSegmento(perfilador.actor, perfilador.edad));
            } else if (getSegmento(perfilador.actor, null) == pensionado){
                window.location.href = getUrlSitio(perfilador.actor);
            } else if (getSegmento(perfilador.actor, null) == empresas){
                jQuery('.perfilador').fadeOut();
				jQuery('body').css('overflow', 'visible');
            } else if (getSegmento(perfilador.actor, null) == sinPerfil){
                jQuery('.perfilador').fadeOut();
				jQuery('body').css('overflow', 'visible');
            } else if (getSegmento(perfilador.actor, null) == otroMomento) {
                jQuery('.perfilador').fadeOut();
				jQuery('body').css('overflow', 'visible');
            }
            delete perfilador.otroMomento;
            localStorage.setItem("perfilador", JSON.stringify(perfilador));
        } else {
            if (getSegmento(perfilador.actor, perfilador.edad) == generacion ||
                getSegmento(perfilador.actor, perfilador.edad) == construyendo ||
                getSegmento(perfilador.actor, perfilador.edad) == consolidando ||
                getSegmento(perfilador.actor, perfilador.edad) == disfrutando) {
                window.location.href = getUrlSitio(getSegmento(perfilador.actor, perfilador.edad));
            } else if (getSegmento(perfilador.actor, null) == pensionado) {
                window.location.href = getUrlSitio(perfilador.actor);
            } else if (getSegmento(perfilador.actor, null) == empresas) {
                window.location.href = getUrlSitio(perfilador.actor);
            } else if (getSegmento(perfilador.actor, null) == sinPerfil) {
                jQuery('.perfilador').fadeOut();
				jQuery('body').css('overflow', 'visible');
            } else if (getSegmento(perfilador.actor, null) == otroMomento) {
                jQuery('.perfilador').fadeOut();
				jQuery('body').css('overflow', 'visible');
            }
        }
    }
}

function esHome() {
    var urlActualConSlash = establecerSlashFinalUrl(location.pathname);
    var urlPorvenirConSlash = establecerSlashFinalUrl(url_sitio_porvenir);
    if (urlActualConSlash == urlPorvenirConSlash) {
        return true;
    } else {
        return false;
    }
    return true;
}

//Cambia de color la barra y menú de navegacion dependiendo el perfil
function setPerfiladorBarColor(colorClase) {
    jQuery('.zp-perfiladorBar').hide();
    jQuery('.menuPorvenir').hide(); 
    jQuery('.zp-perfiladorBar.' + getColorClase(colorClase)).show();
    jQuery('.menuPorvenir.' + getColorClase(colorClase)).show();
} // fin setPerfiladorBarColor()

function ultimoString(stri) {
    return stri.substr(stri.length - 1);
} // fin ultimoString

function establecerSlashFinalUrl(stringUrl) {
    if (stringUrl.trim().length > 0) {
        var ultimoCaracter = ultimoString(stringUrl);
        if (ultimoCaracter != "/") {
            stringUrl = stringUrl + "/";
        }
    }
    return stringUrl;
} // fin ultimoString

function storageDisponible(type) {
    try {
        var storage = window[type],
            x = '__storage_test__';
        storage.setItem(x, x);
        storage.removeItem(x);
        return true;
    } catch (e) {
        return e instanceof DOMException && (
                // todo excepto Firefox
                e.code === 22 ||
                // Firefox
                e.code === 1014 ||
                // prueba campo nombre también, el código puede no estar presente
                // todo excepto Firefox
                e.name === 'QuotaExceededError' ||
                // Firefox
                e.name === 'NS_ERROR_DOM_QUOTA_REACHED') &&
            // reconocer QuotaExceededError solo si ya hay algo almacenado
            storage.length !== 0;
    }
}


function getUrlSitio(sitio) {
    var urlSitio = "";
    switch (sitio) {
        case generacion:
            urlSitio = url_sitio_generacion_porvenir;
            break;
        case construyendo:
            urlSitio = url_sitio_construyendo_porvenir;
            break;
        case consolidando:
            urlSitio = url_sitio_consolidando_porvenir;
            break;
        case disfrutando:
            urlSitio = url_sitio_disfrutando_porvenir;
            break;
        case empresas:
            urlSitio = url_sitio_empresa_porvenir;
			break;
        case pensionado:
            urlSitio = url_sitio_invalidez_supervivencia;
            break;
        default:
            urlSitio = url_sitio_porvenir;
            break;
    }
    return urlSitio;
} //fin getUrlSitio()

function getColorClase(colorClase) {
    var stringColorClase = "";
    switch (colorClase) {
        case generacion:
            stringColorClase = "lime";
            break;
        case construyendo:
            stringColorClase = "yellow";
            break;
        case consolidando:
            stringColorClase = "orange";
            break;
        case disfrutando:
            stringColorClase = "green";
            break;
        case empresas:
            stringColorClase = "barra-empresa";
            break;
        case sinPerfil:
            stringColorClase = "sin-perfilar";
            break;
        case pensionado:
            stringColorClase = "sin-perfilar";
            break;
        default:
            stringColorClase = "sin-perfilar";
            break;
    }
    return stringColorClase;
} //fin getColorClase()

function getClasesColor() {
    var clasesColor = [getColorClase(generacion)
                      ,getColorClase(construyendo)
                      ,getColorClase(consolidando)
                      ,getColorClase(disfrutando)
                      ,getColorClase(empresas)
                      ,getColorClase(sinPerfil)
                      ,getColorClase(pensionado)];
    return clasesColor;
}

function getSegmento(actor, valor) {
    var segmento = undefined;
    if (actor == mujer) {
        if (valor >= "18" && valor <= "28") {
            segmento = generacion;
        } else if (valor >= "29" && valor <= "46") {
            segmento = construyendo;
        } else if (valor >= "47" && valor <= "56") {
            segmento = consolidando;
        } else if (valor >= "57") {
            segmento = disfrutando;
        } else {
            segmento = undefined;
        }
    } else if (actor == hombre) {
        if (valor >= "18" && valor <= "28") {
            segmento = generacion;
        } else if (valor >= "29" && valor <= "51") {
            segmento = construyendo;
        } else if (valor >= "52" && valor <= "61") {
            segmento = consolidando;
        } else if (valor >= "62") {
            segmento = disfrutando;
        } else {
            segmento = undefined;
        }
    } else if (actor == empresas) {
        segmento = empresas;
    } else if (actor == pensionado) {
        segmento = pensionado;
    } else if (actor == sinPerfil) {
        segmento = sinPerfil;
    }

    return segmento;
}

function isOtroMomento(){
 if (storageDisponible('sessionStorage')) {
    var perfilador = sessionStorage.getItem("perfilador");
    if (perfilador !== undefined && perfilador !== null) {
        perfilador = JSON.parse( perfilador );
        if ( perfilador.hasOwnProperty("otroMomento" ) ){
            return true;
        }else{
            return false;
        }
    }else{
        return false;
    }
    
 }else{
    return false;
 }
}

function resetPantallaSeleccionPerfilador(){
    jQuery('.section-mujer').hide();
    jQuery('.section-hombre').hide();
    jQuery('.section-options, .salir-perfilador').show();
}
// Validacion perfilador para SYQ

function validacionSYQ() {
    var urlSyq = '/web/syqquejasyreclamos';
    var urlActualConSlash = establecerSlashFinalUrl(location.pathname);
    var verificador = 0;
    for(var i=0; i<urlSyq.length; i++){
        if(urlSyq[i] == urlActualConSlash[i]){
            verificador++;
        }
        if(verificador == urlSyq.length){
            return false;
        }
    }
    return true;
}