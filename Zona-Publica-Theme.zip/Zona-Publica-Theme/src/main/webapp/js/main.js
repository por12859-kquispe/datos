	/*AUI().ready(


	This function gets loaded when all the HTML, not including the portlets, is
	loaded.
	

	function() {
	}
);*/
/*
Liferay.Portlet.ready(

	
	This function gets loaded after each and every portlet on the page.

	portletId: the current portlet's id
	node: the Alloy Node object of the current portlet
	

	function(portletId, node) {
	}
);*/
/*
Liferay.on(
	'allPortletsReady',

	
	This function gets loaded when everything, including the portlets, is on
	the page.
	

	function() {
	}
);
*/
(function($) {
    $.fn.fontResize = function(options) {
        var increaseCount = 0;
        var self = this;

        var changeFont = function(element, amount) {
            var baseFontSize = parseInt($('html').css("font-size"));
            element.css('font-size', (baseFontSize + amount) + 'px');
        };

        options.increaseBtn.on('click', function(e) {
            e.preventDefault();
            if (increaseCount === 2) {
                return;
            }
            self.each(function(index, element) {
                changeFont($(element), 2);
            });
            increaseCount++;
        });

        options.decreaseBtn.on('click', function(e) {
            e.preventDefault();
            if (increaseCount === 0) {
                return;
            }
            self.each(function(index, element) {
                changeFont($(element), -2);
            });
            increaseCount--;
        });
    }
})(jQuery);

//Validar disponibilidad del LocalStorage
function storageDisponible(type) {
    try {
        var storage = window[type],
            x = '__storage_test__';
        storage.setItem(x, x);
        storage.removeItem(x);
        return true;
    } catch (e) {
        return e instanceof DOMException && (
                // todo excepto Firefox
                e.code === 22 ||
                // Firefox
                e.code === 1014 ||
                // prueba campo nombre también, el código puede no estar presente
                // todo excepto Firefox
                e.name === 'QuotaExceededError' ||
                // Firefox
                e.name === 'NS_ERROR_DOM_QUOTA_REACHED') &&
            // reconocer QuotaExceededError solo si ya hay algo almacenado
            storage.length !== 0;
    }
}

$(function() {

    // zoom tools
    $(".usertools__btn").click(function(e) {
        e.preventDefault();
        $(".usertools").toggleClass("active");
    });

    $('html').fontResize({
        increaseBtn: $('.agrandar-letra'),
        decreaseBtn: $('.achicar-letra')
    });
    
	
	// cerrar cookies

	$('.btn--close-alert, .zp-alerta-box--cookies--btn').click(function () {
		$(this).parent().fadeOut();
		if (storageDisponible('localStorage')) {
        try{
            localStorage.setItem("cookies", true);
        }catch(e){
            console.error(e);
        }
        }
	});

	$('.close-alert-info, .close-alert').click(function () {
		$(this).parents('.zp-alerta-box').slideUp();
	});
    
    $(document).ready(function() {
    	try{
    	if(typeof(Storage) !== "undefined") {
    		 var cookies = localStorage.getItem("cookies");
    		 if(cookies){
    			 $('.zp-alerta-box--cookies').fadeOut();
    		 }else{
    			 $('.zp-alerta-box--cookies').fadeIn(); 
    		 }
    	 }else{
    		 $('.zp-alerta-box--cookies').fadeIn();
    	 }
    	 }catch(e){
    		 $('.zp-alerta-box--cookies').fadeIn();
    	 }
    })

	// menu footer
	
	$('.footer--publico .dropdown-toggle').click(function () {
	   
	    $(this).parent().siblings().children().next().fadeOut().removeClass('active');
	    $(this).parent().siblings().removeClass('opened');
	    $(this).next('ul').slideToggle();
	    $(this).parent().toggleClass('opened');
	    $("html, body").animate({ scrollTop: $(document).height() }, 800);
	    return false;
	});
    
    moveScroller();

    function moveScroller() {
        var $anchor = $("#scroller-anchor");
        var $scroller = $('.zp-header-publico, .zp-content');

        var move = function() {
            var st = $(window).scrollTop();
            var ot = $anchor.offset().top;
               if ($('body').width()<768){
                      if(st > ot) {
                    $scroller.addClass('menuIsSticky')
                } else {
                    $scroller.removeClass('menuIsSticky')
                }
               }
               else{
                $scroller.removeClass('menuIsSticky') 
            }
        };
        $(window).scroll(move);
        move();
    }
    
    $(document).ready(function(){
       moveScroller();
    })
    $(document).on('change mouseover','body',function(){
       moveScroller();
    })


    // submenu	
     $( ".dropdown-toggle" ).click(function() {
            
           
            $(this).next(".journal-content-article").slideToggle();
            $(this).parent().toggleClass('activeItem');
            $(this).parent().siblings().children().next().slideUp();
            $(this).parent().siblings().removeClass('activeItem');
           
            return false

        });
	
     $( ".dropdown-toggle-submenu" ).click(function() {
            
            $('.dropdown-toggle-submenu').removeClass('activeItem');
            $( this ).next(".zp-dropdown-submenu").slideToggle();
            $( this ).toggleClass('activeItem');
            $(this).parent().siblings().children().next().slideUp();
            $(this).parent().siblings().children().removeClass('activeItem');
           
            return false

        });
     
     $(document).click(function(e) {
    	    var container = $(".zp-dropdown .journal-content-article");
    	    if (!container.is(e.target) && container.has(e.target).length === 0) {
    	        $(".dropdown-toggle").parent().siblings().children().next().slideUp('fast');
    	        $(".dropdown-toggle").parent().siblings().removeClass('activeItem');
    	    }
    	});
     
     
    // tooltip
    $('[data-toggle="tooltip"]').tooltip(); 
    
    // Componente Ancla
    $(".zp-anclas-list__item a").on('click', function(e) {
        e.preventDefault();
        var target = $(this).attr('href');
        $('html, body').animate({
          scrollTop: ($(target).offset().top - 80)
        }, 1500);
     });


    // funcion para mostrar/ocultar acordeon
    $('[data-toggle="collapse"]').click(function(e){
    	  e.preventDefault();
    	  $(this).toggleClass('opened');
});

// alerta seguir leyendo


$(window).scroll(function() {
    if ($(window).scrollTop() >= 400 && $(window).scrollTop() <= ($(document).height() - 400)) {
        $('.zp-alerta-leyendo').fadeOut();
    }
    else {
        $('.zp-alerta-leyendo').fadeIn();
    }
});

})

// Funcion para cargar el modal de Opinat
function loadOpinatModal(surveyUrl){
	document.getElementById('opinatIframe').setAttribute('src', surveyUrl);
	document.getElementById('modalEncuesta').style.display = "block";
	document.getElementById('modalEncuesta').style.opacity = 1;
}